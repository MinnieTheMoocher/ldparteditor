java -Djava.library.path='natives/' -jar SearchForUpdates.jar
