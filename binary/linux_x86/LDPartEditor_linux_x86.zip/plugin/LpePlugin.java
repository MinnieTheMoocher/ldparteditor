// AUTO GENERATED PLUGIN
import org.nschmidt.ldparteditor.plugin.Plugin;

public class LpePlugin extends Plugin {
    
    public LpePlugin() {
	
    }
    
    @Override
    public String getPlugInAuthor() {
	return "Nils Schmidt [BlackBrick89]";
    }
    
    @Override
    public String getPlugInName() {
	return "blah";
    }
    
    
}
