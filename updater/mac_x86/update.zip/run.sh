java -XstartOnFirstThread -Djava.library.path='natives/' -jar LDPartEditor.jar
